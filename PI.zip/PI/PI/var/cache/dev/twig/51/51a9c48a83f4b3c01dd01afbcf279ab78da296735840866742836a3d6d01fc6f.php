<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_ee822e1e8e7b60c106d7e66d1c80dae9983d2a01eca79b305df0e419e859d94a extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'header' => [$this, 'block_header'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <<meta charset=\"UTF-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">
        <meta name=\"author\" content=\"Jobboard\">

        <title>";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <!-- Favicon -->
        <link rel=\"shortcut icon\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/favicon.png"), "html", null, true);
        echo "\">
        <!-- Bootstrap CSS -->
        <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/bootstrap.min.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/jasny-bootstrap.min.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/bootstrap-select.min.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <!-- Material CSS -->
        <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/material-kit.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <!-- Font Awesome CSS -->
        <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/font-awesome.min.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/themify-icons.css"), "html", null, true);
        echo "\">

        <!-- Animate CSS -->
        <link rel=\"stylesheet\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/extras/animate.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <!-- Owl Carousel -->
        <link rel=\"stylesheet\" href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/extras/owl.carousel.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <link rel=\"stylesheet\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/extras/owl.theme.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <!-- Rev Slider CSS -->
        <link rel=\"stylesheet\" href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/extras/settings.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <!-- Slicknav js -->
        <link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/slicknav.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <!-- Main Styles -->
        <link rel=\"stylesheet\" href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\">
        <!-- Responsive CSS Styles -->
        <link rel=\"stylesheet\" href=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/responsive.css"), "html", null, true);
        echo "\" type=\"text/css\">

        <!-- Color CSS Styles  -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/colors/red.css"), "html", null, true);
        echo "\" media=\"screen\" />
    </head>
    <body>
        ";
        // line 42
        $this->displayBlock('header', $context, $blocks);
        // line 322
        echo "        ";
        $this->displayBlock('content', $context, $blocks);
        // line 379
        echo "        ";
        $this->displayBlock('footer', $context, $blocks);
        // line 476
        echo "        ";
        $this->displayBlock('js', $context, $blocks);
        // line 493
        echo "
    </body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 10
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "findjob app";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 42
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header"));

        // line 43
        echo "            <div class=\"header\">
                <div class=\"logo-menu\">
                    <nav class=\"navbar navbar-default main-navigation\" role=\"navigation\" data-spy=\"affix\" data-offset-top=\"50\">
                        <div class=\"container\">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class=\"navbar-header\">
                                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#navbar\">
                                    <span class=\"sr-only\">Toggle navigation</span>
                                    <span class=\"icon-bar\"></span>
                                    <span class=\"icon-bar\"></span>
                                    <span class=\"icon-bar\"></span>
                                </button>
                                <a class=\"navbar-brand logo\" href=\"";
        // line 55
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\"><img src=\"assets/img/logo.png\" alt=\"\"></a>
                            </div>

                            <div class=\"collapse navbar-collapse\" id=\"navbar\">
                                <!-- Start Navigation List -->
                                <ul class=\"nav navbar-nav\">
                                    <li>
                                        <a href=\"index.html\">
                                            Home <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a class=\"active\" href=\"index.html\">
                                                    Home 1
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"index-02.html\">
                                                    Home 2
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"index-03.html\">
                                                    Home 3
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"index-04.html\">
                                                    Home 4
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href=\"about.html\">
                                            Pages <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a href=\"about.html\">
                                                    About
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"job-page.html\">
                                                    Job Page
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"job-details.html\">
                                                    Job Details
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"resume.html\">
                                                    Resume Page
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"privacy-policy.html\">
                                                    Privacy Policy
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"faq.html\">
                                                    FAQ
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"pricing.html\">
                                                    Pricing Tables
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"contact.html\">
                                                    Contact
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href=\"#\">
                                            Candidates <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a href=\"browse-jobs.html\">
                                                    Browse Jobs
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"browse-categories.html\">
                                                    Browse Categories
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"add-resume.html\">
                                                    Add Resume
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"manage-resumes.html\">
                                                    Manage Resumes
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"job-alerts.html\">
                                                    Job Alerts
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a class=\"active\" href=\"#\">
                                            Employers <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a class=\"active\" href=\"post-job.html\">
                                                    Add Job
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"manage-jobs.html\">
                                                    Manage Jobs
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"manage-applications.html\">
                                                    Manage Applications
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"browse-resumes.html\">
                                                    Browse Resumes
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href=\"blog.html\">
                                            Blog <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a href=\"blog.html\">
                                                    Blog - Right Sidebar
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"blog-left-sidebar.html\">
                                                    Blog - Left Sidebar
                                                </a>
                                            </li>
                                            <li><a href=\"blog-full-width.html\">Blog - Full Width</a></li>
                                            <li>
                                                <a href=\"single-post.html\">
                                                    Blog Single Post
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                                <ul class=\"nav navbar-nav navbar-right float-right\">
                                    <li class=\"left\"><a href=\"";
        // line 219
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("post");
        echo "\"><i class=\"ti-pencil-alt\"></i> Post A Job</a></li>
                                    <li class=\"right\"><a href=\"my-account.html\"><i class=\"ti-lock\"></i>  Log In</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- Mobile Menu Start -->
                        <ul class=\"wpb-mobile-menu\">
                            <li>
                                <a href=\"index.html\">Home</a>
                                <ul>
                                    <li><a href=\"index.html\">Home 1</a></li>
                                    <li><a href=\"index-02.html\">Home 2</a></li>
                                    <li><a href=\"index-03.html\">Home 3</a></li>
                                    <li><a href=\"index-04.html\">Home 4</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href=\"about.html\">Pages</a>
                                <ul>
                                    <li><a href=\"about.html\">About</a></li>
                                    <li><a href=\"job-page.html\">Job Page</a></li>
                                    <li><a href=\"job-details.html\">Job Details</a></li>
                                    <li><a href=\"resume.html\">Resume Page</a></li>
                                    <li><a href=\"privacy-policy.html\">Privacy Policy</a></li>
                                    <li><a href=\"faq.html\">FAQ</a></li>
                                    <li><a href=\"pricing.html\">Pricing Tables</a></li>
                                    <li><a href=\"contact.html\">Contact</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href=\"#\">For Candidates</a>
                                <ul>
                                    <li><a href=\"browse-jobs.html\">Browse Jobs</a></li>
                                    <li><a href=\"browse-categories.html\">Browse Categories</a></li>
                                    <li><a href=\"add-resume.html\">Add Resume</a></li>
                                    <li><a href=\"manage-resumes.html\">Manage Resumes</a></li>
                                    <li><a href=\"job-alerts.html\">Job Alerts</a></li>
                                </ul>
                            </li>
                            <li>
                                <a class=\"active\" href=\"#\">For Employers</a>
                                <ul>
                                    <li><a class=\"active\" href=\"post-job.html\">Add Job</a></li>
                                    <li><a href=\"manage-jobs.html\">Manage Jobs</a></li>
                                    <li><a href=\"manage-applications.html\">Manage Applications</a></li>
                                    <li><a href=\"browse-resumes.html\">Browse Resumes</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href=\"blog.html\">Blog</a>
                                <ul class=\"dropdown\">
                                    <li><a href=\"blog.html\">Blog - Right Sidebar</a></li>
                                    <li><a href=\"blog-left-sidebar.html\">Blog - Left Sidebar</a></li>
                                    <li><a href=\"blog-full-width.html\">Blog - Full Width</a></li>
                                    <li><a href=\"single-post.html\">Blog Single Post</a></li>
                                </ul>
                            </li>
                            <li class=\"btn-m\"><a href=\"post-job.html\"><i class=\"ti-pencil-alt\"></i> Post A Job</a></li>
                            <li class=\"btn-m\"><a href=\"my-account.html\"><i class=\"ti-lock\"></i>  Log In</a></li>
                        </ul>
                        <!-- Mobile Menu End -->
                    </nav>

                    <!-- Off Canvas Navigation -->
                    <div class=\"navmenu navmenu-default navmenu-fixed-left offcanvas\">
                        <!--- Off Canvas Side Menu -->
                        <div class=\"close\" data-toggle=\"offcanvas\" data-target=\".navmenu\">
                            <i class=\"ti-close\"></i>
                        </div>
                        <h3 class=\"title-menu\">All Pages</h3>
                        <ul class=\"nav navmenu-nav\">
                            <li><a href=\"index.html\">Home</a></li>
                            <li><a href=\"index-02.html\">Home Page 2</a></li>
                            <li><a href=\"index-03.html\">Home Page 3</a></li>
                            <li><a href=\"index-04.html\">Home Page 4</a></li>
                            <li><a href=\"about.html\">About us</a></li>
                            <li><a href=\"job-page.html\">Job Page</a></li>
                            <li><a href=\"job-details.html\">Job Details</a></li>
                            <li><a href=\"resume.html\">Resume Page</a></li>
                            <li><a href=\"privacy-policy.html\">Privacy Policy</a></li>
                            <li><a href=\"pricing.html\">Pricing Tables</a></li>
                            <li><a href=\"browse-jobs.html\">Browse Jobs</a></li>
                            <li><a href=\"browse-categories.html\">Browse Categories</a></li>
                            <li><a href=\"add-resume.html\">Add Resume</a></li>
                            <li><a href=\"manage-resumes.html\">Manage Resumes</a></li>
                            <li><a href=\"job-alerts.html\">Job Alerts</a></li>
                            <li><a href=\"post-job.html\">Add Job</a></li>
                            <li><a href=\"manage-jobs.html\">Manage Jobs</a></li>
                            <li><a href=\"manage-applications.html\">Manage Applications</a></li>
                            <li><a href=\"browse-resumes.html\">Browse Resumes</a></li>
                            <li><a href=\"contact.html\">Contact</a></li>
                            <li><a href=\"faq.html\">Faq</a></li>
                            <li><a href=\"my-account.html\">Login</a></li>
                        </ul><!--- End Menu -->
                    </div> <!--- End Off Canvas Side Menu -->
                    <div class=\"tbtn wow pulse\" id=\"menu\" data-wow-iteration=\"infinite\" data-wow-duration=\"500ms\" data-toggle=\"offcanvas\" data-target=\".navmenu\">
                        <p><i class=\"ti-files\"></i> All Pages</p>
                    </div>
                </div>
                <!-- Header Section End -->

                <!-- end intro section -->
            </div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 322
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 323
        echo "            <section id=\"intro\" class=\"section-intro\">
            <div class=\"search-container\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <h1>Find the job that fits your life</h1><br><h2>More than <strong>12,000</strong> jobs are waiting to Kickstart your career!</h2>
                            <div class=\"content\">
                                <form method=\"\" action=\"\">
                                    <div class=\"row\">
                                        <div class=\"col-md-4 col-sm-6\">
                                            <div class=\"form-group\">
                                                <input class=\"form-control\" type=\"text\" placeholder=\"job title / keywords / company name\">
                                                <i class=\"ti-time\"></i>
                                            </div>
                                        </div>
                                        <div class=\"col-md-4 col-sm-6\">
                                            <div class=\"form-group\">
                                                <input class=\"form-control\" type=\"email\" placeholder=\"city / province / zip code\">
                                                <i class=\"ti-location-pin\"></i>
                                            </div>
                                        </div>
                                        <div class=\"col-md-3 col-sm-6\">
                                            <div class=\"search-category-container\">
                                                <label class=\"styled-select\">
                                                    <select class=\"dropdown-product selectpicker\">
                                                        <option>All Categories</option>
                                                        <option>Finance</option>
                                                        <option>IT & Engineering</option>
                                                        <option>Education/Training</option>
                                                        <option>Art/Design</option>
                                                        <option>Sale/Markting</option>
                                                        <option>Healthcare</option>
                                                        <option>Science</option>
                                                        <option>Food Services</option>
                                                    </select>
                                                </label>
                                            </div>
                                        </div>
                                        <div class=\"col-md-1 col-sm-6\">
                                            <button type=\"button\" class=\"btn btn-search-icon\"><i class=\"ti-search\"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class=\"popular-jobs\">
                                <b>Popular Keywords: </b>
                                <a href=\"#\">Web Design</a>
                                <a href=\"#\">Manager</a>
                                <a href=\"#\">Programming</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 379
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 380
        echo "            <!-- Footer Section Start -->
            <footer>
                <!-- Footer Area Start -->
                <section class=\"footer-Content\">
                    <div class=\"container\">
                        <div class=\"row\">
                            <div class=\"col-md-3 col-sm-6 col-xs-12\">
                                <div class=\"widget\">
                                    <h3 class=\"block-title\"><img src=\"assets/img/logo.png\" class=\"img-responsive\" alt=\"Footer Logo\"></h3>
                                    <div class=\"textwidget\">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque lobortis tincidunt est, et euismod purus suscipit quis. Etiam euismod ornare elementum. Sed ex est, consectetur eget facilisis sed.</p>
                                    </div>
                                </div>
                            </div>
                            <div class=\"col-md-3 col-sm-6 col-xs-12\">
                                <div class=\"widget\">
                                    <h3 class=\"block-title\">Quick Links</h3>
                                    <ul class=\"menu\">
                                        <li><a href=\"#\">About Us</a></li>
                                        <li><a href=\"#\">Support</a></li>
                                        <li><a href=\"#\">License</a></li>
                                        <li><a href=\"#\">Terms & Conditions</a></li>
                                        <li><a href=\"#\">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class=\"col-md-3 col-sm-6 col-xs-12\">
                                <div class=\"widget\">
                                    <h3 class=\"block-title\">Trending Jobs</h3>
                                    <ul class=\"menu\">
                                        <li><a href=\"#\">Android Developer</a></li>
                                        <li><a href=\"#\">Senior Accountant</a></li>
                                        <li><a href=\"#\">Frontend Developer</a></li>
                                        <li><a href=\"#\">Junior Tester</a></li>
                                        <li><a href=\"#\">Project Manager</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class=\"col-md-3 col-sm-6 col-xs-12\">
                                <div class=\"widget\">
                                    <h3 class=\"block-title\">Follow Us</h3>
                                    <div class=\"bottom-social-icons social-icon\">
                                        <a class=\"twitter\" href=\"https://twitter.com/GrayGrids\"><i class=\"ti-twitter-alt\"></i></a>
                                        <a class=\"facebook\" href=\"https://web.facebook.com/GrayGrids\"><i class=\"ti-facebook\"></i></a>
                                        <a class=\"youtube\" href=\"https://youtube.com\"><i class=\"ti-youtube\"></i></a>
                                        <a class=\"dribble\" href=\"https://dribbble.com/GrayGrids\"><i class=\"ti-dribbble\"></i></a>
                                        <a class=\"linkedin\" href=\"https://www.linkedin.com/GrayGrids\"><i class=\"ti-linkedin\"></i></a>
                                    </div>
                                    <p>Join our mailing list to stay up to date and get notices about our new releases!</p>
                                    <form class=\"subscribe-box\">
                                        <input type=\"text\" placeholder=\"Your email\">
                                        <input type=\"submit\" class=\"btn-system\" value=\"Send\">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Footer area End -->

                <!-- Copyright Start  -->
                <div id=\"copyright\">
                    <div class=\"container\">
                        <div class=\"row\">
                            <div class=\"col-md-12\">
                                <div class=\"site-info text-center\">
                                    Shared by <i class=\"fa fa-love\"></i><a href=\"https://bootstrapthemes.co\">BootstrapThemes</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Copyright End -->

            </footer>
            <!-- Footer Section End -->

            <!-- Go To Top Link -->
            <a href=\"#\" class=\"back-to-top\">
                <i class=\"ti-arrow-up\"></i>
            </a>

            <div id=\"loading\">
                <div id=\"loading-center\">
                    <div id=\"loading-center-absolute\">
                        <div class=\"object\" id=\"object_one\"></div>
                        <div class=\"object\" id=\"object_two\"></div>
                        <div class=\"object\" id=\"object_three\"></div>
                        <div class=\"object\" id=\"object_four\"></div>
                        <div class=\"object\" id=\"object_five\"></div>
                        <div class=\"object\" id=\"object_six\"></div>
                        <div class=\"object\" id=\"object_seven\"></div>
                        <div class=\"object\" id=\"object_eight\"></div>
                    </div>
                </div>
            </div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 476
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 477
        echo "            <script type=\"text/javascript\" src=\"assets/js/jquery-min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/bootstrap.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/material.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/material-kit.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.parallax.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/owl.carousel.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.slicknav.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/main.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.counterup.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/waypoints.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jasny-bootstrap.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/bootstrap-select.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/form-validator.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/contact-form-script.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.themepunch.revolution.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.themepunch.tools.min.js\"></script>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  686 => 477,  676 => 476,  571 => 380,  561 => 379,  496 => 323,  486 => 322,  373 => 219,  206 => 55,  192 => 43,  182 => 42,  163 => 10,  150 => 493,  147 => 476,  144 => 379,  141 => 322,  139 => 42,  133 => 39,  127 => 36,  122 => 34,  117 => 32,  112 => 30,  107 => 28,  103 => 27,  98 => 25,  92 => 22,  88 => 21,  83 => 19,  78 => 17,  74 => 16,  70 => 15,  65 => 13,  59 => 10,  48 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <<meta charset=\"UTF-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">
        <meta name=\"author\" content=\"Jobboard\">

        <title>{% block title %}findjob app{% endblock %}</title>

        <!-- Favicon -->
        <link rel=\"shortcut icon\" href=\"{{ asset(\"assets/img/favicon.png\")}}\">
        <!-- Bootstrap CSS -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/css/bootstrap.min.css\")}}\" type=\"text/css\">
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/css/jasny-bootstrap.min.css\")}}\" type=\"text/css\">
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/css/bootstrap-select.min.css\")}}\" type=\"text/css\">
        <!-- Material CSS -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/css/material-kit.css\")}}\" type=\"text/css\">
        <!-- Font Awesome CSS -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/fonts/font-awesome.min.css\")}}\" type=\"text/css\">
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/fonts/themify-icons.css\")}}\">

        <!-- Animate CSS -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/extras/animate.css\")}}\" type=\"text/css\">
        <!-- Owl Carousel -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/extras/owl.carousel.css\")}}\" type=\"text/css\">
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/extras/owl.theme.css\")}}\" type=\"text/css\">
        <!-- Rev Slider CSS -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/extras/settings.css\")}}\" type=\"text/css\">
        <!-- Slicknav js -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/css/slicknav.css\")}}\" type=\"text/css\">
        <!-- Main Styles -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/css/main.css\")}}\" type=\"text/css\">
        <!-- Responsive CSS Styles -->
        <link rel=\"stylesheet\" href=\"{{ asset(\"assets/css/responsive.css\")}}\" type=\"text/css\">

        <!-- Color CSS Styles  -->
        <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset(\"assets/css/colors/red.css\")}}\" media=\"screen\" />
    </head>
    <body>
        {% block header %}
            <div class=\"header\">
                <div class=\"logo-menu\">
                    <nav class=\"navbar navbar-default main-navigation\" role=\"navigation\" data-spy=\"affix\" data-offset-top=\"50\">
                        <div class=\"container\">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class=\"navbar-header\">
                                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#navbar\">
                                    <span class=\"sr-only\">Toggle navigation</span>
                                    <span class=\"icon-bar\"></span>
                                    <span class=\"icon-bar\"></span>
                                    <span class=\"icon-bar\"></span>
                                </button>
                                <a class=\"navbar-brand logo\" href=\"{{ path('home') }}\"><img src=\"assets/img/logo.png\" alt=\"\"></a>
                            </div>

                            <div class=\"collapse navbar-collapse\" id=\"navbar\">
                                <!-- Start Navigation List -->
                                <ul class=\"nav navbar-nav\">
                                    <li>
                                        <a href=\"index.html\">
                                            Home <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a class=\"active\" href=\"index.html\">
                                                    Home 1
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"index-02.html\">
                                                    Home 2
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"index-03.html\">
                                                    Home 3
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"index-04.html\">
                                                    Home 4
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href=\"about.html\">
                                            Pages <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a href=\"about.html\">
                                                    About
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"job-page.html\">
                                                    Job Page
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"job-details.html\">
                                                    Job Details
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"resume.html\">
                                                    Resume Page
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"privacy-policy.html\">
                                                    Privacy Policy
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"faq.html\">
                                                    FAQ
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"pricing.html\">
                                                    Pricing Tables
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"contact.html\">
                                                    Contact
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href=\"#\">
                                            Candidates <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a href=\"browse-jobs.html\">
                                                    Browse Jobs
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"browse-categories.html\">
                                                    Browse Categories
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"add-resume.html\">
                                                    Add Resume
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"manage-resumes.html\">
                                                    Manage Resumes
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"job-alerts.html\">
                                                    Job Alerts
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a class=\"active\" href=\"#\">
                                            Employers <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a class=\"active\" href=\"post-job.html\">
                                                    Add Job
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"manage-jobs.html\">
                                                    Manage Jobs
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"manage-applications.html\">
                                                    Manage Applications
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"browse-resumes.html\">
                                                    Browse Resumes
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href=\"blog.html\">
                                            Blog <i class=\"fa fa-angle-down\"></i>
                                        </a>
                                        <ul class=\"dropdown\">
                                            <li>
                                                <a href=\"blog.html\">
                                                    Blog - Right Sidebar
                                                </a>
                                            </li>
                                            <li>
                                                <a href=\"blog-left-sidebar.html\">
                                                    Blog - Left Sidebar
                                                </a>
                                            </li>
                                            <li><a href=\"blog-full-width.html\">Blog - Full Width</a></li>
                                            <li>
                                                <a href=\"single-post.html\">
                                                    Blog Single Post
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                                <ul class=\"nav navbar-nav navbar-right float-right\">
                                    <li class=\"left\"><a href=\"{{ path('post') }}\"><i class=\"ti-pencil-alt\"></i> Post A Job</a></li>
                                    <li class=\"right\"><a href=\"my-account.html\"><i class=\"ti-lock\"></i>  Log In</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- Mobile Menu Start -->
                        <ul class=\"wpb-mobile-menu\">
                            <li>
                                <a href=\"index.html\">Home</a>
                                <ul>
                                    <li><a href=\"index.html\">Home 1</a></li>
                                    <li><a href=\"index-02.html\">Home 2</a></li>
                                    <li><a href=\"index-03.html\">Home 3</a></li>
                                    <li><a href=\"index-04.html\">Home 4</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href=\"about.html\">Pages</a>
                                <ul>
                                    <li><a href=\"about.html\">About</a></li>
                                    <li><a href=\"job-page.html\">Job Page</a></li>
                                    <li><a href=\"job-details.html\">Job Details</a></li>
                                    <li><a href=\"resume.html\">Resume Page</a></li>
                                    <li><a href=\"privacy-policy.html\">Privacy Policy</a></li>
                                    <li><a href=\"faq.html\">FAQ</a></li>
                                    <li><a href=\"pricing.html\">Pricing Tables</a></li>
                                    <li><a href=\"contact.html\">Contact</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href=\"#\">For Candidates</a>
                                <ul>
                                    <li><a href=\"browse-jobs.html\">Browse Jobs</a></li>
                                    <li><a href=\"browse-categories.html\">Browse Categories</a></li>
                                    <li><a href=\"add-resume.html\">Add Resume</a></li>
                                    <li><a href=\"manage-resumes.html\">Manage Resumes</a></li>
                                    <li><a href=\"job-alerts.html\">Job Alerts</a></li>
                                </ul>
                            </li>
                            <li>
                                <a class=\"active\" href=\"#\">For Employers</a>
                                <ul>
                                    <li><a class=\"active\" href=\"post-job.html\">Add Job</a></li>
                                    <li><a href=\"manage-jobs.html\">Manage Jobs</a></li>
                                    <li><a href=\"manage-applications.html\">Manage Applications</a></li>
                                    <li><a href=\"browse-resumes.html\">Browse Resumes</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href=\"blog.html\">Blog</a>
                                <ul class=\"dropdown\">
                                    <li><a href=\"blog.html\">Blog - Right Sidebar</a></li>
                                    <li><a href=\"blog-left-sidebar.html\">Blog - Left Sidebar</a></li>
                                    <li><a href=\"blog-full-width.html\">Blog - Full Width</a></li>
                                    <li><a href=\"single-post.html\">Blog Single Post</a></li>
                                </ul>
                            </li>
                            <li class=\"btn-m\"><a href=\"post-job.html\"><i class=\"ti-pencil-alt\"></i> Post A Job</a></li>
                            <li class=\"btn-m\"><a href=\"my-account.html\"><i class=\"ti-lock\"></i>  Log In</a></li>
                        </ul>
                        <!-- Mobile Menu End -->
                    </nav>

                    <!-- Off Canvas Navigation -->
                    <div class=\"navmenu navmenu-default navmenu-fixed-left offcanvas\">
                        <!--- Off Canvas Side Menu -->
                        <div class=\"close\" data-toggle=\"offcanvas\" data-target=\".navmenu\">
                            <i class=\"ti-close\"></i>
                        </div>
                        <h3 class=\"title-menu\">All Pages</h3>
                        <ul class=\"nav navmenu-nav\">
                            <li><a href=\"index.html\">Home</a></li>
                            <li><a href=\"index-02.html\">Home Page 2</a></li>
                            <li><a href=\"index-03.html\">Home Page 3</a></li>
                            <li><a href=\"index-04.html\">Home Page 4</a></li>
                            <li><a href=\"about.html\">About us</a></li>
                            <li><a href=\"job-page.html\">Job Page</a></li>
                            <li><a href=\"job-details.html\">Job Details</a></li>
                            <li><a href=\"resume.html\">Resume Page</a></li>
                            <li><a href=\"privacy-policy.html\">Privacy Policy</a></li>
                            <li><a href=\"pricing.html\">Pricing Tables</a></li>
                            <li><a href=\"browse-jobs.html\">Browse Jobs</a></li>
                            <li><a href=\"browse-categories.html\">Browse Categories</a></li>
                            <li><a href=\"add-resume.html\">Add Resume</a></li>
                            <li><a href=\"manage-resumes.html\">Manage Resumes</a></li>
                            <li><a href=\"job-alerts.html\">Job Alerts</a></li>
                            <li><a href=\"post-job.html\">Add Job</a></li>
                            <li><a href=\"manage-jobs.html\">Manage Jobs</a></li>
                            <li><a href=\"manage-applications.html\">Manage Applications</a></li>
                            <li><a href=\"browse-resumes.html\">Browse Resumes</a></li>
                            <li><a href=\"contact.html\">Contact</a></li>
                            <li><a href=\"faq.html\">Faq</a></li>
                            <li><a href=\"my-account.html\">Login</a></li>
                        </ul><!--- End Menu -->
                    </div> <!--- End Off Canvas Side Menu -->
                    <div class=\"tbtn wow pulse\" id=\"menu\" data-wow-iteration=\"infinite\" data-wow-duration=\"500ms\" data-toggle=\"offcanvas\" data-target=\".navmenu\">
                        <p><i class=\"ti-files\"></i> All Pages</p>
                    </div>
                </div>
                <!-- Header Section End -->

                <!-- end intro section -->
            </div>{% endblock %}
        {% block content %}
            <section id=\"intro\" class=\"section-intro\">
            <div class=\"search-container\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-md-12\">
                            <h1>Find the job that fits your life</h1><br><h2>More than <strong>12,000</strong> jobs are waiting to Kickstart your career!</h2>
                            <div class=\"content\">
                                <form method=\"\" action=\"\">
                                    <div class=\"row\">
                                        <div class=\"col-md-4 col-sm-6\">
                                            <div class=\"form-group\">
                                                <input class=\"form-control\" type=\"text\" placeholder=\"job title / keywords / company name\">
                                                <i class=\"ti-time\"></i>
                                            </div>
                                        </div>
                                        <div class=\"col-md-4 col-sm-6\">
                                            <div class=\"form-group\">
                                                <input class=\"form-control\" type=\"email\" placeholder=\"city / province / zip code\">
                                                <i class=\"ti-location-pin\"></i>
                                            </div>
                                        </div>
                                        <div class=\"col-md-3 col-sm-6\">
                                            <div class=\"search-category-container\">
                                                <label class=\"styled-select\">
                                                    <select class=\"dropdown-product selectpicker\">
                                                        <option>All Categories</option>
                                                        <option>Finance</option>
                                                        <option>IT & Engineering</option>
                                                        <option>Education/Training</option>
                                                        <option>Art/Design</option>
                                                        <option>Sale/Markting</option>
                                                        <option>Healthcare</option>
                                                        <option>Science</option>
                                                        <option>Food Services</option>
                                                    </select>
                                                </label>
                                            </div>
                                        </div>
                                        <div class=\"col-md-1 col-sm-6\">
                                            <button type=\"button\" class=\"btn btn-search-icon\"><i class=\"ti-search\"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class=\"popular-jobs\">
                                <b>Popular Keywords: </b>
                                <a href=\"#\">Web Design</a>
                                <a href=\"#\">Manager</a>
                                <a href=\"#\">Programming</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {% endblock %}
        {% block footer %}
            <!-- Footer Section Start -->
            <footer>
                <!-- Footer Area Start -->
                <section class=\"footer-Content\">
                    <div class=\"container\">
                        <div class=\"row\">
                            <div class=\"col-md-3 col-sm-6 col-xs-12\">
                                <div class=\"widget\">
                                    <h3 class=\"block-title\"><img src=\"assets/img/logo.png\" class=\"img-responsive\" alt=\"Footer Logo\"></h3>
                                    <div class=\"textwidget\">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque lobortis tincidunt est, et euismod purus suscipit quis. Etiam euismod ornare elementum. Sed ex est, consectetur eget facilisis sed.</p>
                                    </div>
                                </div>
                            </div>
                            <div class=\"col-md-3 col-sm-6 col-xs-12\">
                                <div class=\"widget\">
                                    <h3 class=\"block-title\">Quick Links</h3>
                                    <ul class=\"menu\">
                                        <li><a href=\"#\">About Us</a></li>
                                        <li><a href=\"#\">Support</a></li>
                                        <li><a href=\"#\">License</a></li>
                                        <li><a href=\"#\">Terms & Conditions</a></li>
                                        <li><a href=\"#\">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class=\"col-md-3 col-sm-6 col-xs-12\">
                                <div class=\"widget\">
                                    <h3 class=\"block-title\">Trending Jobs</h3>
                                    <ul class=\"menu\">
                                        <li><a href=\"#\">Android Developer</a></li>
                                        <li><a href=\"#\">Senior Accountant</a></li>
                                        <li><a href=\"#\">Frontend Developer</a></li>
                                        <li><a href=\"#\">Junior Tester</a></li>
                                        <li><a href=\"#\">Project Manager</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class=\"col-md-3 col-sm-6 col-xs-12\">
                                <div class=\"widget\">
                                    <h3 class=\"block-title\">Follow Us</h3>
                                    <div class=\"bottom-social-icons social-icon\">
                                        <a class=\"twitter\" href=\"https://twitter.com/GrayGrids\"><i class=\"ti-twitter-alt\"></i></a>
                                        <a class=\"facebook\" href=\"https://web.facebook.com/GrayGrids\"><i class=\"ti-facebook\"></i></a>
                                        <a class=\"youtube\" href=\"https://youtube.com\"><i class=\"ti-youtube\"></i></a>
                                        <a class=\"dribble\" href=\"https://dribbble.com/GrayGrids\"><i class=\"ti-dribbble\"></i></a>
                                        <a class=\"linkedin\" href=\"https://www.linkedin.com/GrayGrids\"><i class=\"ti-linkedin\"></i></a>
                                    </div>
                                    <p>Join our mailing list to stay up to date and get notices about our new releases!</p>
                                    <form class=\"subscribe-box\">
                                        <input type=\"text\" placeholder=\"Your email\">
                                        <input type=\"submit\" class=\"btn-system\" value=\"Send\">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Footer area End -->

                <!-- Copyright Start  -->
                <div id=\"copyright\">
                    <div class=\"container\">
                        <div class=\"row\">
                            <div class=\"col-md-12\">
                                <div class=\"site-info text-center\">
                                    Shared by <i class=\"fa fa-love\"></i><a href=\"https://bootstrapthemes.co\">BootstrapThemes</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Copyright End -->

            </footer>
            <!-- Footer Section End -->

            <!-- Go To Top Link -->
            <a href=\"#\" class=\"back-to-top\">
                <i class=\"ti-arrow-up\"></i>
            </a>

            <div id=\"loading\">
                <div id=\"loading-center\">
                    <div id=\"loading-center-absolute\">
                        <div class=\"object\" id=\"object_one\"></div>
                        <div class=\"object\" id=\"object_two\"></div>
                        <div class=\"object\" id=\"object_three\"></div>
                        <div class=\"object\" id=\"object_four\"></div>
                        <div class=\"object\" id=\"object_five\"></div>
                        <div class=\"object\" id=\"object_six\"></div>
                        <div class=\"object\" id=\"object_seven\"></div>
                        <div class=\"object\" id=\"object_eight\"></div>
                    </div>
                </div>
            </div>{% endblock %}
        {% block js %}
            <script type=\"text/javascript\" src=\"assets/js/jquery-min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/bootstrap.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/material.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/material-kit.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.parallax.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/owl.carousel.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.slicknav.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/main.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.counterup.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/waypoints.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jasny-bootstrap.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/bootstrap-select.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/form-validator.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/contact-form-script.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.themepunch.revolution.min.js\"></script>
            <script type=\"text/javascript\" src=\"assets/js/jquery.themepunch.tools.min.js\"></script>{% endblock %}

    </body>
</html>
", "base.html.twig", "C:\\wamp64\\www\\PI\\PI\\templates\\base.html.twig");
    }
}
